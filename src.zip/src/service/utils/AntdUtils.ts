export interface CascaderOption {
    value: number;
    label: string;
    children?: CascaderOption[];
}