export const BACK_HOST = `http://${process.env.REACT_APP_API_BASE_URL}:34443`
export const DEFAULT_DATE_TIME_PATTERN = "YYYY-MM-DDTHH:mm:ss"