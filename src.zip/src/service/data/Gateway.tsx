export interface User{
    id?: number,
    username?: string,
    password?: string,
    email?: string,
    phone?: string,
    gender?: string,
    avatar?: string,
    createTime?: string
}