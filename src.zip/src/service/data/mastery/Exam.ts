export interface Exam{
    id: number,
    rootId: number,
    userId: number,
    examStrategy: string
}