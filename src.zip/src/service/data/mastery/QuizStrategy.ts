export interface QuizStrategy{
    type: string
    config: object
}