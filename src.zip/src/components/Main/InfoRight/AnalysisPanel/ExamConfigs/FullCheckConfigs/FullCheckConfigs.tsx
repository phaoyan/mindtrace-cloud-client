import React from 'react';
import CurrentKnodeInfo from "../utils/CurrentKnodeInfo";

const FullCheckConfigs = () => {
    return <CurrentKnodeInfo/>
};

export default FullCheckConfigs;