import React from 'react';
import CurrentKnodeInfo from "../utils/CurrentKnodeInfo";

const HeuristicConfigs = () => {
    return <CurrentKnodeInfo/>
};

export default HeuristicConfigs;