import {atom} from "recoil";

export const RecentKnodeMainMsgAtom = atom({
    key: "RecentKnodeMainMsgAtom",
    default: {}
})

export const RecentKnodeStatisticMsgAtom = atom({
    key: "RecentKnodeStatisticMsgAtom",
    default: {}
})

