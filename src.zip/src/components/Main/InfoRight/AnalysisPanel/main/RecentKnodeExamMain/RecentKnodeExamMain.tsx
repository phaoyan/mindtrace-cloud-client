import React from 'react';

const RecentKnodeExamMain = () => {
    return (
        <div>

        </div>
    );
};

export default RecentKnodeExamMain;