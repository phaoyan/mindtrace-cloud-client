import React from 'react';
import {Col, Row} from "antd";

const BasicInfoPanel = () => {

    return (
        <div>
            <Row>
                <Col span={24}>
                </Col>
            </Row>
        </div>
    );
};

export default BasicInfoPanel;